@section('title', __('Dashboard'))
<x-dashboard-layout>
    <div>
        <div class="w-full px-6">
            <div class="md:inline-flex float-right pt-2 pb-5 sm:flex sm:flex-wrap">
                <x-button type="button" primary data-date="today" class="js-date mr-2 active">
                    {{ __('Today') }}
                </x-button>

                <x-button type="button" primary data-date="month" class="js-date mr-2">
                    {{ __('Last month') }}
                </x-button>

                <x-button type="button" primary data-date="semi" class="js-date mr-2">
                    {{ __('Last 6 month') }}
                </x-button>

                <x-button type="button" primary data-date="year" class="js-date">
                    {{ __('Last year') }}
                </x-button>
            </div>
            @foreach ($customData as $key => $d)
                @if ($loop->first)
                    <div class="w-full flex flex-wrap align-center mb-4 js-date-row" id="{{ $key }}">
                        <div class="grid gap-6 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 w-full">
                            <div class="flex items-center p-4 bg-white rounded-lg shadow-md">
                                <div>
                                    <p class="mb-2 text-lg font-medium text-gray-600">
                                        {{ __('Customers') }}
                                    </p>
                                    <p class="text-3xl sm:text-lg font-bold text-gray-700">
                                        {{ $d['countCustomers'] }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="w-full flex flex-wrap align-center mb-4 js-date-row" style="display: none"
                        id="{{ $key }}">
                        <div class="grid gap-6 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 w-full">
                            <div class="flex items-center p-4 bg-white rounded-lg shadow-md">
                                <div>
                                    <p class="mb-2 text-lg font-medium text-gray-600">
                                        {{ __('Customers') }}
                                    </p>
                                    <p class="text-3xl sm:text-lg font-bold text-gray-700">
                                        {{ $d['countCustomers'] }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach

        </div>
        
        <div class="w-full px-6  my-4">
        @livewire('tools.qr-generator')
        </div>
        
        <div class="w-full px-6  my-4">
            @livewire('visual-editor')
        </div>
        <div class="w-full px-6 flex flex-row my-4">

            <div class="lg:w-full px-4">
                <x-card>
                    <h5 class="font-bold py-2 text-xl">{{ __('Recent Customer(s)') }}</h5>
                    <div class="card-body">

                        <div class="table-responsive  dashboard-home-table">
                            <x-table>
                                <x-slot name="thead">
                                    <x-table.tr>
                                        <x-table.th>{{ __('Customer Email') }}</x-table.th>
                                        <x-table.th>{{ __('Joined') }}</x-table.th>
                                    </x-table.tr>
                                </x-slot>
                                <x-table.tbody>
                                    @foreach ($recentUsers as $data)
                                        <x-table.tr>
                                            <x-table.td>{{ $data->email }}</x-table.td>
                                            <x-table.td>{{ $data->created_at }}</x-table.td>
                                        </x-table.tr>
                                    @endforeach
                                </x-table.tbody>
                            </x-table>
                        </div>
                    </div>
                </x-card>
            </div>
        </div>

    </div>
</x-dashboard-layout>

@section('scripts')

    <script>
        document.querySelectorAll('.js-date').forEach(el => {
            el.addEventListener('click', event => {
                clearActive();
                hideAll();
                el.classList.add('active');
                document.querySelector(`#${el.dataset.date}`).style.display = 'flex';
            });
        });

        const clearActive = () => {
            document.querySelectorAll('.js-date').forEach(el => {
                el.classList.remove('active');
            });
        };

        const hideAll = () => {
            document.querySelectorAll('.js-date-row').forEach(el => {
                el.style.display = 'none';
            });
        };
    </script>
@endsection
